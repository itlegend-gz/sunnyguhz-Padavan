#ifndef GBCONV_H
#define GBCONV_H

#include <stdlib.h>
#include <stdint.h>

size_t gbconv8(const char *src, size_t srclen, char *dst, size_t dstlen);

#endif
